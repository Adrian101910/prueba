char my_toupper(char c)
{
    if (c >= 'A' && c <= 'Z')
    {
        return c - ('A' - 'a');
    }
    return c;
}

char *ft_strlowcase(char *str)
{
    char *original_str = str; 

    while (*str)
    {
        *str = my_toupper(*str); 
        str++; 
    }

    return original_str;
}
