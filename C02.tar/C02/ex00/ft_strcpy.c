char    *ft_strcpy(char *dest, char *src)
{
    char *destino1 = dest; //guardamos la posicion inicial del destino 

    while (*src != '\0')    //copiamos cada parte del src en el destino;
    {
        *dest = *src;
        dest++;
        src++;
    }
    *dest = '\0'; //añadimos para indicar el final

    return destino1; //devolvemos el puntero al inicio del destino
    
}