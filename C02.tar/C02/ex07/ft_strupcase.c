char my_toupper(char c)
{
    if (c >= 'a' && c <= 'z')
    {
        return c - ('a' - 'A');
    }
    return c;
}

char *ft_strupcase(char *str)
{
    char *original_str = str; 

    while (*str)
    {
        *str = my_toupper(*str); 
        str++; 
    }

    return original_str;
}
